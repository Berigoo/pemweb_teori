<?php
    $hostname = "localhost";
    $user = "me";
    $passwd = "";
    $db = "pbw";

    $conn = mysqli_connect($hostname, $user, $passwd, $db) or die("error");
?>

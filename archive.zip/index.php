<?php
header('Location: /form.php', true, 301);





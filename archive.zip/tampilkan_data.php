<?php
include "koneksi.php";

$query = mysqli_query($conn, "SELECT * FROM mahasiswa");
